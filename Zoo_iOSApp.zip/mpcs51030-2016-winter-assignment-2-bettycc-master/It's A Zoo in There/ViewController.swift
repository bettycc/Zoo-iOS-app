//
//  ViewController.swift
//  It's A Zoo in There
//
//  Created by Betty on 1/13/16.
//  Copyright © 2016 Betty. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var scrollView: UIScrollView!

    @IBOutlet weak var pageControl: UIPageControl!
    
    @IBOutlet weak var buttomLabel: UILabel!
    
    var sound_0 : AVAudioPlayer?
    var sound_1 : AVAudioPlayer?
    var sound_2 : AVAudioPlayer?
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        if let sound_0 = setupAudioPlayerWithFile("sound_0", type:"mp3") {
            self.sound_0 = sound_0
        }
        if let sound_1 = setupAudioPlayerWithFile("sound_1", type:"mp3") {
            self.sound_1 = sound_1
        }
        if let sound_2 = setupAudioPlayerWithFile("sound_2", type:"wav") {
            self.sound_2 = sound_2
        }
        
        
        
        
        scrollView.contentSize = CGSize(width: 1125, height: 500)
        
        //create an array that hold 3 animal objects
        var threeAnimals = [Animal]()
        
        //create 3 UIImage objects, because each Animal obj contain an instance of one UIImage
        let image_0 : UIImage! = UIImage(named:"lion")
        let image_1 : UIImage! = UIImage(named:"pig")
        let image_2 : UIImage! = UIImage(named:"puma")
        
        //create 3 animal objects
        let animal_0 = Animal(name: "Lion", species: "P. leo", age: 5, image: image_0);
        let animal_1 = Animal(name: "Pig", species: "P. leo", age: 10, image: image_1);
        let animal_2 = Animal(name: "Puma", species: "P. leo", age: 15, image: image_2);
        
        //append the three Animal objects to the array
        threeAnimals.append(animal_0)
        threeAnimals.append(animal_1)
        threeAnimals.append(animal_2)
        
        //call shuffle()
        threeAnimals.shuffle()
        
        
        let imageView_0 = UIImageView(image: image_0)
        imageView_0.frame = CGRect(x: 0, y: 100, width: 375, height: 300)
        imageView_0.contentMode = .ScaleAspectFit
        let button_0 = UIButton(frame: CGRect(x: 125, y: 10, width: 125, height: 60))
        button_0.setTitle("Lion", forState: .Normal)
        //button_0.backgroundColor = UIColor.darkGrayColor()
        button_0.setTitleColor(UIColor.darkGrayColor(),forState: .Normal)
        button_0.tag = 0
        button_0.addTarget(self, action: "buttonTapped:", forControlEvents:UIControlEvents.TouchUpInside)
        
        let imageView_1 = UIImageView(image: image_1)
        imageView_1.frame = CGRect(x: 375, y: 100, width: 375, height: 300)
        let button_1 = UIButton(frame: CGRect(x: 500, y: 10, width: 125, height: 60))
        button_1.setTitle("Pig", forState: .Normal)
        button_1.setTitleColor(UIColor.darkGrayColor(),forState: .Normal)
        button_1.tag = 1
        button_1.addTarget(self, action: "buttonTapped:", forControlEvents:UIControlEvents.TouchUpInside)
        
        let imageView_2 = UIImageView(image: image_2)
        imageView_2.frame = CGRect(x: 750, y: 100, width: 375, height: 300)
        let button_2 = UIButton(frame: CGRect(x: 875, y: 10, width: 125, height: 60))
        button_2.setTitle("Puma", forState: .Normal)
        button_2.setTitleColor(UIColor.darkGrayColor(),forState: .Normal)
        button_2.tag = 2
        button_2.addTarget(self, action: "buttonTapped:", forControlEvents:UIControlEvents.TouchUpInside)
        
        scrollView.addSubview(imageView_0)
        scrollView.addSubview(imageView_1)
        scrollView.addSubview(imageView_2)
        scrollView.addSubview(button_0)
        scrollView.addSubview(button_1)
        scrollView.addSubview(button_2)
        scrollViewDidEndDecelerating(scrollView)
       
    }
    
    //Action for UIScrollDelegate
    func scrollViewDidEndDecelerating(scrollView: UIScrollView){
        
        scrollView.delegate=self
//        //create a label
//        let buttomLabel = UILabel(frame: CGRect(x: 0, y: 500, width: 375, height: 100))
//        //set the Label text
        buttomLabel.textColor = UIColor.blueColor()
        buttomLabel.text = "Lion"
//        scrollView.addSubview(buttomLabel)
        
        // Test the offset and calculate the current page after scrolling ends
        let pageWidth:CGFloat = CGRectGetWidth(scrollView.frame)
        let currentPage: CGFloat = (1125-scrollView.contentOffset.x)/375
        // Change the indicator
        self.pageControl.currentPage = Int(currentPage);
        // Change the text accordingly
        if Int(currentPage) == 0{
            buttomLabel.text = "Lion"
        }else if Int(currentPage) == 1{
            buttomLabel.text = "Puma"
        }else if Int(currentPage) == 2{
            buttomLabel.text = "Pig"
        }
    
    }
    
    func setupAudioPlayerWithFile(file:NSString, type:NSString) -> AVAudioPlayer?  {
        //1
        let path = NSBundle.mainBundle().pathForResource(file as String, ofType: type as String)
        let url = NSURL.fileURLWithPath(path!)
        
        //2
        var audioPlayer:AVAudioPlayer?
        
        // 3
        do {
            try audioPlayer = AVAudioPlayer(contentsOfURL: url)
        } catch {
            print("Player not available")
        }
        
        return audioPlayer
    }

    func buttonTapped(sender:UIButton!){

        
        if sender.tag == 0 {
            print(sender.tag)
            print(sender)
            
            let image_0 : UIImage! = UIImage(named:"lion")
            let animal_0 = Animal(name: "Lion", species: "P. leo", age: 5, image: image_0);
            
            let alertController_0 = UIAlertController(title: animal_0.name, message: "The \(animal_0.name) is \(animal_0.age) years old.", preferredStyle: .Alert)
            let defaultAction_0 = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alertController_0.addAction(defaultAction_0)
            
            presentViewController(alertController_0, animated: true, completion: nil)
            
            print(animal_0.dumpAnimalObject())
            
            sound_0?.play()
        }
        
        if sender.tag == 1 {
            print("1")
            
            let image_1 : UIImage! = UIImage(named:"pig")
            let animal_1 = Animal(name: "Pig", species: "P. leo", age: 10, image: image_1);
            
            let alertController_1 = UIAlertController(title: animal_1.name, message: "The \(animal_1.name) is \(animal_1.age) years old.", preferredStyle: .Alert)
            let defaultAction_1 = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alertController_1.addAction(defaultAction_1)
            
            presentViewController(alertController_1, animated: true, completion: nil)
            
            print(animal_1.dumpAnimalObject())
            
            sound_1?.play()
        }
        if sender.tag == 2 {
            print("2")
            
            let image_2 : UIImage! = UIImage(named:"puma")
            let animal_2 = Animal(name: "Puma", species: "P. leo", age: 15, image: image_2);
            
            let alertController_0 = UIAlertController(title: animal_2.name, message: "The \(animal_2.name) is \(animal_2.age) years old.", preferredStyle: .Alert)
            let defaultAction_0 = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alertController_0.addAction(defaultAction_0)
            
            presentViewController(alertController_0, animated: true, completion: nil)
            
            print(animal_2.dumpAnimalObject())
            
            sound_2?.play()
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    


}

