//
//  ArrayExtensions.swift
//  It's A Zoo in There
//
//  Created by Betty on 1/14/16.
//  Copyright © 2016 Betty. All rights reserved.
//

import Foundation

extension Array {
    
    //add a new function, called shuffle()
    //Randomizes the order of an array's elements.
    //arc4random() returns a random number
    
    mutating func shuffle(){
        
        for _ in 0..<3{
            
            sortInPlace { (_,_) in arc4random() < arc4random() }
        }
    }
}

    

