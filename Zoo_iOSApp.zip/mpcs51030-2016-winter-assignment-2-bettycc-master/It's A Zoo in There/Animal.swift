//
//  Animal.swift
//  It's A Zoo in There
//
//  Created by Betty on 1/14/16.
//  Copyright © 2016 Betty. All rights reserved.
//

import Foundation

import UIKit

class Animal{
    
    let name: String
    let species: String
    let age: Int
    let image: UIImage
    
    init(name: String, species: String, age: Int, image: UIImage){
        self.name = name
        self.species = species
        self.age = age
        self.image = image
    }
    
    func dumpAnimalObject(){
        print("> Animal Object name=\(name), species=\(species), age=\(age), image=\(image)")
    }
    
}
